# Lumen dei Morti — app per iOS e Android

Il gioco è in `www/` (un'unica pagina, funziona offline). Le cartelle `ios/` e `android/` sono i progetti nativi Capacitor già configurati: icona, schermata di avvio, schermo intero, vibrazione, schermo sempre acceso, tasto Indietro di Android.

Ci sono tre modi per averlo sul telefono, dal più rapido al più completo.

## 1. PWA: icona sulla schermata Home, senza store (iOS e Android)

1. Crea un repository su GitHub e carica questa cartella (anche trascinando i file nel sito di GitHub).
2. Nel repository: **Settings → Pages → Source: GitHub Actions**.
3. Al primo push il workflow «PWA su GitHub Pages» pubblica il gioco su `https://<tuo-utente>.github.io/<repository>/`.
4. Apri quel link sul telefono:
   - **iPhone (Safari):** Condividi → «Aggiungi alla schermata Home».
   - **Android (Chrome):** menu ⋮ → «Installa app».

Si apre a schermo intero e funziona anche senza rete.

## 2. APK Android, senza installare nulla sul Mac

Con il repository su GitHub, il workflow «APK Android» compila l'app a ogni push.

1. Vai su **Actions → APK Android**, apri l'ultima esecuzione e scarica l'artefatto `Lumen-dei-Morti-android`.
2. Copia `app-debug.apk` sul telefono e aprilo. Android chiederà di consentire l'installazione da questa fonte.

## 3. Compilare sul tuo Mac (iPhone e Android, e per gli store)

Servono Node.js 22 o successivo, Xcode 16 o successivo (per iOS) e Android Studio (per Android).

```bash
npm install
npm run ios       # apre il progetto in Xcode
npm run android   # apre il progetto in Android Studio
```

**iPhone**
1. In Xcode: target *App* → *Signing & Capabilities* → scegli il tuo Team (basta l'Apple ID gratuito).
2. Collega l'iPhone, selezionalo in alto e premi ▶︎.
3. Sull'iPhone, la prima volta: *Impostazioni → Generali → VPN e gestione dispositivi* → autorizza il tuo profilo sviluppatore.

Con l'Apple ID gratuito l'app va reinstallata ogni 7 giorni. Per l'App Store o TestFlight serve l'Apple Developer Program (99 €/anno).

**Android**
In Android Studio premi ▶︎ con il telefono collegato (Opzioni sviluppatore → Debug USB). Per il Play Store: *Build → Generate Signed App Bundle*.

## Dopo una modifica al gioco

Modifica `www/index.html`, poi esegui `npx cap sync` per copiarlo nei progetti nativi.

## Dati dell'app

| | |
| --- | --- |
| Nome | Lumen dei Morti |
| Identificativo (bundle id / package) | `com.lumendeimorti.app` — cambialo in `capacitor.config.json` prima di pubblicare, ad esempio con il tuo dominio |
| Orientamento | verticale e orizzontale |
| Android minimo | 7.0 (API 24) |
| iOS minimo | quello del template Capacitor 8 (iOS 15) |
